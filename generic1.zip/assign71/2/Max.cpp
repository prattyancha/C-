#include<iostream>
#include<stdio.h>
using namespace std;


//Generic implimentation

template <class T>
T Max(T no1,T no2,T no3)
{
	T no=0;
	if(no1>=no2 && no1>=no3)
	{
		no=no1;	
	}
	else if(no2>=no1 && no2>=no3)
	{
		no=no2;
	}
	else
	{
		no=no3;
	}
	return no;
}


int main()
{
	int value1,value2,value3;
	int iret=0;
	cout<<"1st no:\n";
	cin>>value1;
	cout<<"2nd no:\n";
	cin>>value2;
	cout<<"3rd no:\n";
	cin>>value3;
	iret = Max(value1,value2,value3);
	cout<<"maximum number is : "<<iret<<"\n";
	
	float fvalue1,fvalue2,fvalue3;
	float fret=0.0;
	cout<<"1st no:\n";
	cin>>fvalue1;
	cout<<"2nd no:\n";
	cin>>fvalue2;
	cout<<"3rd no:\n";
	cin>>fvalue3;
	fret = Max(fvalue1,fvalue2,fvalue3);
	cout<<"maximum number is : "<<fret<<"\n";
	return 0;
}