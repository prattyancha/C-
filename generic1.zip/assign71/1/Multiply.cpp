#include<iostream>
#include<stdio.h>
using namespace std;


//Generic implimentation

template <class T>
T Multiply(T no1,T no2)
{
	T ans=0;
	ans=no1*no2;
	return ans;
}

int main()
{
	int iRet=Multiply(10,20);
	printf("%d\n",iRet);
	float fRet=Multiply(10.0f,20.5f);
	printf("%f\n",fRet);
	return 0;
}