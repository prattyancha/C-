#include<iostream>
#include<stdio.h>
using namespace std;

template <class T>
int Frequency(T *Arr,int size,T No)
{
	int iCnt=0;
	int i=0;
	for(i=0;i<size;i++)
	{
		if(Arr[i]==No)
		{
			iCnt++;
		}
	}
	return iCnt;
}

int main()
{
	int arr[]={10,20,30,10,50};
	
	int iRet=Frequency(arr,5,10);
	printf("%d\n",iRet);
	
	return 0;
}