#include<iostream>
#include<stdio.h>
using namespace std;

template <class T>
void Reverse(T *Arr,int size)
{
	int i=0;
	for(i=size-1;i>=0;i--)
	{
		cout<<Arr[i]<<"\t";
	}
}


int main()
{
	int arr[]={10,20,30,10,50};
	
	for(int i=0;i<5;i++)
	{
		cout<<arr[i]<<"\t";
	}
	cout<<"\n";
	Reverse(arr,5);
	return 0;
}



//   C:\Program Files\Apache Software Foundation\Tomcat 10.0_Tomcat